package android.render.animations;

import android.content.Context;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

public class Render {
    Context cx;
    boolean visible = true;
    long duration = 1000;

    // Render render = new Render(this)
    public Render  (Context cx) {
        this.cx = cx;
    }

    // render.show(FadeIn, TextView)
    public void show (int anim, View view) {

        if(visible) {
            view.setVisibility(View.VISIBLE);
        } else {
            view.setVisibility(View.INVISIBLE);
        }

        Animation Anim = AnimationUtils.loadAnimation(cx, anim);
        Anim.setDuration(duration);
        view.startAnimation(Anim);

    }

    // render.setvisible(false)
    public void setvisible(boolean visible){
        this.visible = visible;
    }


    // render.setduration(false)
    public void setduration(long duration){
        this.duration = duration;
    }


}
