package android.render.animations;
import android.animation.ObjectAnimator;
import android.view.View;

public class Anim {
    public static int BottomUp(){
        return R.anim.bottom_to_up;
    }

    public static int FadeInLeft(View view){
        ObjectAnimator.ofFloat(view, "alpha", 0, 1);
        return R.animator.fade_in_left;
    }


    /*
        android:propertyName="alpha"
        android:valueFrom="1.0"
        android:valueTo="0.0"
        android:duration="0"

        android:propertyName="rotationY"
        android:valueFrom="-180"
        android:valueTo="0"
        android:interpolator="@android:interpolator/overshoot"
        android:duration="10000"/>




     */
}
