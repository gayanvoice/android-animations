package render.app4;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.render.animations.Anim;
import android.render.animations.Render;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textview = findViewById(R.id.textview1);

        Render render = new Render(this);
        render.setvisible(false);
        render.setduration(1000);
        render.show(Anim.BottomUp(), textview);


    }
}
